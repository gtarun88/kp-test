package com.kp.spring.batch.scheduler.util;

public class ProcessingMessageUtil {
    static  String PLAN_DO_NOT_PAYS = "ANNUAL DECUCTIBLE  (INDIVIDUAL or FAMILY) not met plan pays 0%";
    static  String PLAN_PAYS_INDIVIDUAL = "ANNUAL DECUCTIBLE  (INDIVIDUAL) met plan pays 0%";
    static  String PLAN_PAYS_FAMILY = "ANNUAL DECUCTIBLE  (FAMILY) met plan pays 0%";
}
