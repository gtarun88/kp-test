INSERT INTO plan_descriptions (id,plan_id, plan_name,coverage_type,estimated_premium,annual_deductible_individual,annual_deductible_family)
VALUES (1,'P001', 'Bronze6000/40%/HAS','Family','$ 962','$ 6000','$ 12000');

INSERT INTO plan_descriptions (id,plan_id, plan_name,coverage_type,estimated_premium,annual_deductible_individual,annual_deductible_family)
VALUES (2,'P002', 'Bronze5000/50','Family','$ 1017','$ 5000','$ 10000');

INSERT INTO plan_descriptions (id,plan_id, plan_name,coverage_type,estimated_premium,annual_deductible_individual,annual_deductible_family)
VALUES (3,'P003', 'Bronze4000/20','Family','$ 1045.67','$ 4000','$ 8000');

