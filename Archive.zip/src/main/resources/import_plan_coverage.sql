INSERT INTO plan_coverage (id,main_category,sub_category,plan_001,plan_002,plan_003)
VALUES (1,'Preventive Care', 'ROUTINE PHYSICAL EXAM','No Charge','No Charge','No Charge');

INSERT INTO plan_coverage (id,main_category,sub_category,plan_001,plan_002,plan_003)
VALUES (2,'Preventive Care', 'MAMMOGRAMS','No Charge','No Charge','No Charge');

INSERT INTO plan_coverage (id,main_category,sub_category,plan_001,plan_002,plan_003)
VALUES (3,'Outpatient Services', 'PRIMARY CARE OFFICE VISIT','40% AFTER DEDUCTIBLE','50% AFTER DEDUCTIBLE','60% AFTER DEDUCTIBLE');

INSERT INTO plan_coverage (id,main_category,sub_category,plan_001,plan_002,plan_003)
VALUES (4,'Outpatient Services', 'SPECIALTY CARE OFFICE VISIT','70% AFTER DEDUCTIBLE','80% AFTER DEDUCTIBLE','90% AFTER DEDUCTIBLE');

INSERT INTO plan_coverage (id,main_category,sub_category,plan_001,plan_002,plan_003)
VALUES (5,'Outpatient Services', 'X-RAYS','40% AFTER DEDUCTIBLE','50% AFTER DEDUCTIBLE','60% AFTER DEDUCTIBLE');

INSERT INTO plan_coverage (id,main_category,sub_category,plan_001,plan_002,plan_003)
VALUES (6,'Outpatient Services', 'LAB TESTS','80% AFTER DEDUCTIBLE','90% AFTER DEDUCTIBLE','100% AFTER DEDUCTIBLE');

INSERT INTO plan_coverage (id,main_category,sub_category,plan_001,plan_002,plan_003)
VALUES (7,'Outpatient Services', 'MRI, CT, PET','40% AFTER DEDUCTIBLE','50% AFTER DEDUCTIBLE','60% AFTER DEDUCTIBLE');

INSERT INTO plan_coverage (id,main_category,sub_category,plan_001,plan_002,plan_003)
VALUES (8,'Outpatient Services', 'OUTPATIENT SURGERY','40% AFTER DEDUCTIBLE','50% AFTER DEDUCTIBLE','60% AFTER DEDUCTIBLE');

INSERT INTO plan_coverage (id,main_category,sub_category,plan_001,plan_002,plan_003)
VALUES (9,'Outpatient Services', 'MENTAL HEALTH VISIT','60% AFTER DEDUCTIBLE','70% AFTER DEDUCTIBLE','80% AFTER DEDUCTIBLE');

INSERT INTO plan_coverage (id,main_category,sub_category,plan_001,plan_002,plan_003)
VALUES (10,'Inpatient Hospital Care', 'ROOM AND BOARD','40% AFTER DEDUCTIBLE','50% AFTER DEDUCTIBLE','60% AFTER DEDUCTIBLE');

INSERT INTO plan_coverage (id,main_category,sub_category,plan_001,plan_002,plan_003)
VALUES (11,'Inpatient Hospital Care', 'SURGERY','40% AFTER DEDUCTIBLE','50% AFTER DEDUCTIBLE','60% AFTER DEDUCTIBLE');

INSERT INTO plan_coverage (id,main_category,sub_category,plan_001,plan_002,plan_003)
VALUES (12,'Inpatient Hospital Care', 'ANESTHESIA','40% AFTER DEDUCTIBLE','50% AFTER DEDUCTIBLE','60% AFTER DEDUCTIBLE');

INSERT INTO plan_coverage (id,main_category,sub_category,plan_001,plan_002,plan_003)
VALUES (13,'Inpatient Hospital Care', 'X-RAYS','40% AFTER DEDUCTIBLE','50% AFTER DEDUCTIBLE','60% AFTER DEDUCTIBLE');

INSERT INTO plan_coverage (id,main_category,sub_category,plan_001,plan_002,plan_003)
VALUES (14,'Inpatient Hospital Care', 'LAB TESTS','40% AFTER DEDUCTIBLE','50% AFTER DEDUCTIBLE','60% AFTER DEDUCTIBLE');

INSERT INTO plan_coverage (id,main_category,sub_category,plan_001,plan_002,plan_003)
VALUES (15,'Inpatient Hospital Care', 'MEDICATIONS','40% AFTER DEDUCTIBLE','50% AFTER DEDUCTIBLE','60% AFTER DEDUCTIBLE');

INSERT INTO plan_coverage (id,main_category,sub_category,plan_001,plan_002,plan_003)
VALUES (16,'Inpatient Hospital Care', 'MENTAL HEALTH CARE','40% AFTER DEDUCTIBLE','50% AFTER DEDUCTIBLE','60% AFTER DEDUCTIBLE');

INSERT INTO plan_coverage (id,main_category,sub_category,plan_001,plan_002,plan_003)
VALUES (17,'Maternity', 'ROUTINE PRENATAL CARE VISIT','40% AFTER DEDUCTIBLE','40% AFTER DEDUCTIBLE','30% AFTER DEDUCTIBLE');

INSERT INTO plan_coverage (id,main_category,sub_category,plan_001,plan_002,plan_003)
VALUES (18,'Maternity', 'FIRST POSTPARTUM VISIT','40% AFTER DEDUCTIBLE','40% AFTER DEDUCTIBLE','30% AFTER DEDUCTIBLE');

INSERT INTO plan_coverage (id,main_category,sub_category,plan_001,plan_002,plan_003)
VALUES (19,'Maternity', 'DELIVERY AND INPATIENT WELL-BABY CARE','40% AFTER DEDUCTIBLE','40% AFTER DEDUCTIBLE','30% AFTER DEDUCTIBLE');

INSERT INTO plan_coverage (id,main_category,sub_category,plan_001,plan_002,plan_003)
VALUES (20,'Emergency And Urgent Care', 'EMERGENCY DEPARTMENT VISIT','40% AFTER DEDUCTIBLE','50% AFTER DEDUCTIBLE','60% AFTER DEDUCTIBLE');

INSERT INTO plan_coverage (id,main_category,sub_category,plan_001,plan_002,plan_003)
VALUES (21,'Emergency And Urgent Care', 'URGENT CARE VISIT','40% AFTER DEDUCTIBLE','$ 100','$ 120');

INSERT INTO plan_coverage (id,main_category,sub_category,plan_001,plan_002,plan_003)
VALUES (22,'Emergency And Urgent Care', 'AMBULANCE SERVICES','40% AFTER DEDUCTIBLE','40% AFTER DEDUCTIBLE','30% AFTER DEDUCTIBLE');

INSERT INTO plan_coverage (id,main_category,sub_category,plan_001,plan_002,plan_003)
VALUES (23,'Prescription Drugs', 'GENERIC','60% AFTER DEDUCTIBLE','70% AFTER DEDUCTIBLE','80% AFTER DEDUCTIBLE');

INSERT INTO plan_coverage (id,main_category,sub_category,plan_001,plan_002,plan_003)
VALUES (24,'Prescription Drugs', 'PREFERRED BRAND','50% AFTER DEDUCTIBLE','60% AFTER DEDUCTIBLE','70% AFTER DEDUCTIBLE');

INSERT INTO plan_coverage (id,main_category,sub_category,plan_001,plan_002,plan_003)
VALUES (25,'Prescription Drugs', 'NON-PREFERRED BRAND','40% AFTER DEDUCTIBLE','50% AFTER DEDUCTIBLE','60% AFTER DEDUCTIBLE');

INSERT INTO plan_coverage (id,main_category,sub_category,plan_001,plan_002,plan_003)
VALUES (26,'Prescription Drugs', 'SPECIALTY','40% AFTER DEDUCTIBLE','50% AFTER DEDUCTIBLE','60% AFTER DEDUCTIBLE');

