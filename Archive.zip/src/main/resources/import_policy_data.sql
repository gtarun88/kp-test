INSERT INTO policy_data (id,policy_id,policy_holder_id,first_name,last_name,plan_id,coverage_start_date,coverage_end_date,individual_accumulated_deductible_for_year,family_accumulated_deductible_for_year)
VALUES (1,'100001','1000011','Sam','Collins','P001','37987','','0.00','0.00');

INSERT INTO policy_data (id,policy_id,policy_holder_id,first_name,last_name,plan_id,coverage_start_date,coverage_end_date,individual_accumulated_deductible_for_year,family_accumulated_deductible_for_year)
VALUES (2,'100001','1000012','Jina','Collins','P001','37987','','0.00','0.00');

INSERT INTO policy_data (id,policy_id,policy_holder_id,first_name,last_name,plan_id,coverage_start_date,coverage_end_date,individual_accumulated_deductible_for_year,family_accumulated_deductible_for_year)
VALUES (3,'100001','1000013','Nancy','Collins','P001','40304','','0.00','0.00');

INSERT INTO policy_data (id,policy_id,policy_holder_id,first_name,last_name,plan_id,coverage_start_date,coverage_end_date,individual_accumulated_deductible_for_year,family_accumulated_deductible_for_year)
VALUES (4,'100001','1000014','Jack','Collins','P001','41463','','0.00','0.00');

INSERT INTO policy_data (id,policy_id,policy_holder_id,first_name,last_name,plan_id,coverage_start_date,coverage_end_date,individual_accumulated_deductible_for_year,family_accumulated_deductible_for_year)
VALUES (5,'100001','1000021','Daniel','Hayer','P002','40909','','4000','4000');

INSERT INTO policy_data (id,policy_id,policy_holder_id,first_name,last_name,plan_id,coverage_start_date,coverage_end_date,individual_accumulated_deductible_for_year,family_accumulated_deductible_for_year)
VALUES (6,'100001','1000031','Sally','Adams','P001','42370','','2500','2500');

INSERT INTO policy_data (id,policy_id,policy_holder_id,first_name,last_name,plan_id,coverage_start_date,coverage_end_date,individual_accumulated_deductible_for_year,family_accumulated_deductible_for_year)
VALUES (7,'100001','1000041','Jacke','Seegers','P003','39814','42521','5560.42','5560.42');

INSERT INTO policy_data (id,policy_id,policy_holder_id,first_name,last_name,plan_id,coverage_start_date,coverage_end_date,individual_accumulated_deductible_for_year,family_accumulated_deductible_for_year)
VALUES (8,'100001','1000051','Tom','Haskel','P001','40544','','6712.34','6712.34');

INSERT INTO policy_data (id,policy_id,policy_holder_id,first_name,last_name,plan_id,coverage_start_date,coverage_end_date,individual_accumulated_deductible_for_year,family_accumulated_deductible_for_year)
VALUES (9,'100001','1000061','San','Mildred','P001','42374','','3250.61','3250.61');

INSERT INTO policy_data (id,policy_id,policy_holder_id,first_name,last_name,plan_id,coverage_start_date,coverage_end_date,individual_accumulated_deductible_for_year,family_accumulated_deductible_for_year)
VALUES (10,'100001','1000071','Mack','Lee','P003','40883','42614','4460.82','4460.82');

