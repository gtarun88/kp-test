package com.kp.spring.batch.scheduler.model;

public class PolicyData {

	private String policyId ;
	private String policyHolderId ;
	private String dateofService ;
	private String coverageMainCategory ;
	private String coverageSubCategory ;
	private Object billedAmont ;
	private Object policyHolderPays ;
	private Object planPays ;
	private String ruleUsed ;
	private Object individualAccumulatedDeductibleServiceDate ;
	private Object familyAccumulatedDeductibleServiceDate ;
	private String errorCode ;
	private String errorMessage ;
	private String processingMessage ;

	public String getPolicyId() {
		return policyId;
	}

	public void setPolicyId(String policyId) {
		this.policyId = policyId;
	}

	public String getPolicyHolderId() {
		return policyHolderId;
	}

	public void setPolicyHolderId(String policyHolderId) {
		this.policyHolderId = policyHolderId;
	}

	public String getDateofService() {
		return dateofService;
	}

	public void setDateofService(String dateofService) {
		this.dateofService = dateofService;
	}

	public String getCoverageMainCategory() {
		return coverageMainCategory;
	}

	public void setCoverageMainCategory(String coverageMainCategory) {
		this.coverageMainCategory = coverageMainCategory;
	}

	public String getCoverageSubCategory() {
		return coverageSubCategory;
	}

	public void setCoverageSubCategory(String coverageSubCategory) {
		this.coverageSubCategory = coverageSubCategory;
	}

	public Object getBilledAmont() {
		return billedAmont;
	}

	public void setBilledAmont(Object billedAmont) {
		this.billedAmont = billedAmont;
	}

	public Object getPolicyHolderPays() {
		return policyHolderPays;
	}

	public void setPolicyHolderPays(Object policyHolderPays) {
		this.policyHolderPays = policyHolderPays;
	}

	public Object getPlanPays() {
		return planPays;
	}

	public void setPlanPays(Object planPays) {
		this.planPays = planPays;
	}

	public String getRuleUsed() {
		return ruleUsed;
	}

	public void setRuleUsed(String ruleUsed) {
		this.ruleUsed = ruleUsed;
	}

	public Object getIndividualAccumulatedDeductibleServiceDate() {
		return individualAccumulatedDeductibleServiceDate;
	}

	public void setIndividualAccumulatedDeductibleServiceDate(Object individualAccumulatedDeductibleServiceDate) {
		this.individualAccumulatedDeductibleServiceDate = individualAccumulatedDeductibleServiceDate;
	}

	public Object getFamilyAccumulatedDeductibleServiceDate() {
		return familyAccumulatedDeductibleServiceDate;
	}

	public void setFamilyAccumulatedDeductibleServiceDate(Object familyAccumulatedDeductibleServiceDate) {
		this.familyAccumulatedDeductibleServiceDate = familyAccumulatedDeductibleServiceDate;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getProcessingMessage() {
		return processingMessage;
	}

	public void setProcessingMessage(String processingMessage) {
		this.processingMessage = processingMessage;
	}
}
