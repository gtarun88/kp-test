package com.kp.spring.batch.scheduler.step;

import com.kp.spring.batch.scheduler.model.PolicyData;
import com.kp.spring.batch.scheduler.util.ExcelUtil;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import java.util.List;

public class PolicyJobFlatFileWriter {

    @Bean
    @StepScope
    public FlatFileItemWriter<PolicyData> writer(String outputTransactionFile)
    {
        List<String> fieldHeaderList  = ExcelUtil.getFieldHearerList();
        FlatFileItemWriter<PolicyData> writer = new FlatFileItemWriter<>();
        Resource outputResource = new FileSystemResource(System.getProperty("user.home") + "/Documents/TestProject_New/Test/ProcessedData/"+outputTransactionFile);
        //Resource outputResource = new FileSystemResource(System.getProperty("user.home") + "/Documents/"+outputTransactionFile);
        writer.setResource(outputResource);
        writer.setAppendAllowed(true);
        String columns = String.join(",", fieldHeaderList);
        writer.setHeaderCallback(writer1 -> writer1.write(columns));
        writer.setLineAggregator(new DelimitedLineAggregator<PolicyData>() {
            {
                setDelimiter(",");
                setFieldExtractor(new BeanWrapperFieldExtractor<PolicyData>() {
                    {
                        setNames(ExcelUtil.getHearerList().toArray(new String[0]));
                    }
                });
            }
        });
        return writer;
    }
}
