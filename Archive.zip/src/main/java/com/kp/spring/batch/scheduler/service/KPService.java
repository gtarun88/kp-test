package com.kp.spring.batch.scheduler.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.kp.spring.batch.scheduler.model.PlanCoverage;
import com.kp.spring.batch.scheduler.repository.PlanCoverageRepository;
import com.kp.spring.batch.scheduler.repository.PlanDescriptionsRepository;
import com.kp.spring.batch.scheduler.repository.PlanPolicyDataRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class KPService {
    private static final String SEPARATOR = "::";
    @Autowired
    PlanDescriptionsRepository planDescriptionsRepository;

    @Autowired
    PlanCoverageRepository planCoverageRepository;

    @Autowired
    PlanPolicyDataRepository planPolicyDataRepository;

    public List<String> getPlanIdList(){
        List<String> planIdList = new ArrayList<>();
        planDescriptionsRepository.findAll().forEach(planDescriptions-> planIdList.add(planDescriptions.getPlanId()));
        return planIdList ;
    }

    public List<String> getPolicyIdList() {
        List<String> policyIdList = new ArrayList<>();
        planPolicyDataRepository.findAll().forEach(planPolicyData -> policyIdList.add(planPolicyData.getPolicyId()));
        return policyIdList ;
    }

    public List<String> getPolicyHolderIdList() {
        List<String> policyHolderIdList = new ArrayList<>();
        planPolicyDataRepository.findAll().forEach(planPolicyData -> policyHolderIdList.add(planPolicyData.getPolicyHolderId()));
        return policyHolderIdList ;
    }

    public Map<String, Object> getPlanDeductibleMap(){
        Map<String, Object> planDeductibleMap = new LinkedHashMap<>();
        planDescriptionsRepository.findAll().forEach(planDescriptions->
                planDeductibleMap.put(planDescriptions.getPlanId(),planDescriptions.getAnnualDeductibleIndividual()
                        +SEPARATOR+planDescriptions.getAnnualDeductibleFamily())
        );
        return planDeductibleMap ;
    }

    public Map<String, String> getPolicyPlanRuleMapData() {
        Map<String, String> policyPlanRuleMapData = new LinkedHashMap<>();
        planCoverageRepository.findAll().forEach(planCoverage -> setPlanPolicyData(planCoverage,policyPlanRuleMapData));
        return policyPlanRuleMapData ;
    }


    public Map<String, Object> getPolicyHolderDetailsMapData() {
        Map<String, Object> policyHolderPlanMapData = new LinkedHashMap<>();
        planPolicyDataRepository.findAll().forEach(planPolicyData ->
                policyHolderPlanMapData.put(planPolicyData.getPolicyId() + SEPARATOR + planPolicyData.getPolicyHolderId()
                        , planPolicyData.getPlanId() + SEPARATOR + planPolicyData.getIndividualAccumulatedDeductibleForYear()
                                + SEPARATOR + planPolicyData.getFamilyAccumulatedDeductibleForYear())
        );
        return policyHolderPlanMapData ;
    }

    public void setPlanPolicyData(PlanCoverage planCoverage ,Map<String, String> policyPlanRuleMapData) {
        policyPlanRuleMapData.put(planCoverage.getMainCategory() + SEPARATOR + planCoverage.getSubCategory() + SEPARATOR + "P001", planCoverage.getPlan001());
        policyPlanRuleMapData.put(planCoverage.getMainCategory() + SEPARATOR + planCoverage.getSubCategory() + SEPARATOR + "P002", planCoverage.getPlan002());
        policyPlanRuleMapData.put(planCoverage.getMainCategory() + SEPARATOR + planCoverage.getSubCategory() + "P003", planCoverage.getPlan003());
    }

}
