package com.kp.spring.batch.scheduler.util;

import com.kp.spring.batch.scheduler.controller.UploadController;
import com.kp.spring.batch.scheduler.model.PolicyData;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.util.*;

import static com.kp.spring.batch.scheduler.util.ProcessingMessageUtil.*;

public class ExcelUtil2 {
    private static final Logger LOG = LoggerFactory.getLogger(UploadController.class);
    private static final List<Map<String, Object>> planDescriptionsDataList = new ArrayList<>();
    private static final List<Map<String, Object>> planCoverageList = new ArrayList<>();
    private static final List<Map<String, Object>> policyDataList = new ArrayList<>();
    private static final List<Map<String, Object>> sampleTransactionsList = new ArrayList<>();

    private static final List<String> planIdList = new ArrayList<>();

    private static final Map<String, Object> planDeductibleMap = new LinkedHashMap<>();

    private static final List<String> policyIdList = new ArrayList<>();

    private static final List<String> policyHolderIdList = new ArrayList<>();

    private static final List<String> mainCategoriesService = Arrays.asList("Preventive Care", "Outpatient Services"
            , "Inpatient Hospital Care", "Maternity", "Emergency And Urgent Care", "Prescription Drugs");
    private static final Map<String, String> subCategoryCategoriesMap = new LinkedHashMap<>();
    private static final Map<String, Object> policyHolderPlanMapData = new LinkedHashMap<>();

    private static final Map<String, String> policyPlanRuleMapData = new LinkedHashMap<>();

    private static final Map<String, Object> individualPolicyHolderPlanCalulationMapData = new LinkedHashMap<>();
    private static final Map<String, Object> familyPolicyHolderPlanCalulationMapData = new LinkedHashMap<>();

    private static final String SEPARATOR = "::";
    private static final List<String> headerList = new ArrayList<>();

    private static final List<String> fieldHeaderList = new ArrayList<>();

    private static final List<String> beanFieldHeaderList = new ArrayList<>();


    private static MultipartFile uploadedFile ;



    /*public static void main(String[] args) {
        readExcelData();
        writeCSVData();
    }*/

    private static void setMainCategoriesServiceList() {
        subCategoryCategoriesMap.put("ROUTINE PHYSICAL EXAM, MAMMOGRAMS, ETC.", "Preventive Care");

        subCategoryCategoriesMap.put("PRIMARY CARE OFFICE VISIT", "Outpatient Services");
        subCategoryCategoriesMap.put("SPECIALTY CARE OFFICE VISIT", "Outpatient Services");
        subCategoryCategoriesMap.put("X-RAYS", "Outpatient Services");
        subCategoryCategoriesMap.put("LAB TESTS", "Outpatient Services");
        subCategoryCategoriesMap.put("MRI, CT, PET", "Outpatient Services");
        subCategoryCategoriesMap.put("OUTPATIENT SURGERY", "Outpatient Services");
        subCategoryCategoriesMap.put("MENTAL HEALTH VISIT", "Outpatient Services");

        subCategoryCategoriesMap.put("ROOM AND BOARD, SURGERY, ANESTHESIA, X-RAYS, LAB TESTS, MEDICATIONS, MENTAL HEALTH CARE", "Inpatient Hospital Care");

        subCategoryCategoriesMap.put("ROUTINE PRENATAL CARE VISIT, FIRST POSTPARTUM VISIT", "Maternity");
        subCategoryCategoriesMap.put("DELIVERY AND INPATIENT WELL-BABY CARE", "Maternity");

        subCategoryCategoriesMap.put("EMERGENCY DEPARTMENT VISIT", "Emergency And Urgent Care");
        subCategoryCategoriesMap.put("URGENT CARE VISIT", "Emergency And Urgent Care");
        subCategoryCategoriesMap.put("AMBULANCE SERVICES", "Emergency And Urgent Care");

        subCategoryCategoriesMap.put("GENERIC", "Prescription Drugs");
        subCategoryCategoriesMap.put("PREFERRED BRAND", "Prescription Drugs");
        subCategoryCategoriesMap.put("NON-PREFERRED BRAND", "Prescription Drugs");
        subCategoryCategoriesMap.put("SPECIALTY", "Prescription Drugs");
    }
    /*public  void initializeFileData(MultipartFile file) {
            uploadedFile = file ;
            readExcelData(false);
    }*/
    public  List<PolicyData> readExcelData(boolean scheduler) {
        List<PolicyData> policyDataBeanList = new ArrayList<>() ;
        setMainCategoriesServiceList();
        FileInputStream fis;
        XSSFWorkbook wb = null ;
        try {
            if (scheduler){
                LOG.info("Reading data from scheduler job");
                String filePath = System.getProperty("user.home") + "//Documents//TestProject_New//Test";
                File file = new File(filePath + "//" + "SamplePlanAndTransactionData.xlsx");
                if(file.exists()) {
                    fis = new FileInputStream(file);
                    wb = new XSSFWorkbook(fis);
                }
            }
            else{
                LOG.info("Reading data from uploaded file");
                if(null!=uploadedFile){
                    wb = new XSSFWorkbook(uploadedFile.getInputStream());
                }
            }
            if(null!=wb){
                int rowCounter;
                for (int i = 0; i < wb.getNumberOfSheets(); i++) {
                    XSSFSheet sheet = wb.getSheetAt(i);
                    rowCounter = 0;
                    if ("SampleTransactionsProcessed".equalsIgnoreCase(sheet.getSheetName())) {
                        continue;
                    }
                    populateDataList(rowCounter, sheet);
                }
                //System.out.println(planDescriptionsDataList);
                //System.out.println(policyDataList);
                //System.out.println(sampleTransactionsList);
                //System.out.println(planCoverageList);
                policyDataBeanList = processUploadedData();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return policyDataBeanList ;
    }

    private void populateDataList(int rowCounter, XSSFSheet sheet) {
        List<String> headerListData;
        Map<String, Object> dataMap;
        headerListData = new ArrayList<>();
        int cellCounter;
        String planId;
        int policyId;
        String individualDeductible;
        String familyDeductible;
        int policyHolderId;
        String mainCategory;
        String subCategory;
        String planId_1;
        String planId_2;
        String planId_3;
        for (Row row : sheet) {
            Iterator<Cell> cellIterator = row.cellIterator();
            cellCounter = 0;
            planId = "";
            policyId = 0;
            individualDeductible = "";
            familyDeductible = "";
            policyHolderId = 0;
            mainCategory = "";
            subCategory = "";
            planId_1 = "";
            planId_2 = "";
            planId_3 = "";
            dataMap = new LinkedHashMap<>();
            while (cellIterator.hasNext()) {
                DataFormatter formatter = new DataFormatter();
                Cell cell = cellIterator.next();
                switch (cell.getCellType()) {
                    case STRING:    //field that represents string cell type
                        if (0 == rowCounter) {
                            headerListData.add(cell.getStringCellValue());
                        } else {
                            String cellValue = !cell.getStringCellValue().isEmpty() ? cell.getStringCellValue().trim() : "";
                            if ("PlanCoverage".equalsIgnoreCase(sheet.getSheetName())) {
                                if (mainCategoriesService.contains(cellValue)) {
                                    break;
                                } else {
                                    if ("Sub Category".equalsIgnoreCase(headerListData.get(cellCounter))) {
                                        if (subCategoryCategoriesMap.containsKey(cellValue)) {
                                            dataMap.put(headerListData.get(0), subCategoryCategoriesMap.get(cellValue));
                                        }
                                        mainCategory = subCategoryCategoriesMap.get(cellValue);
                                        subCategory = cellValue;
                                    }
                                    if ("PlanId P001".equalsIgnoreCase(headerListData.get(cellCounter))) {
                                        planId_1 = cellValue;
                                    } else if ("PlanId P002".equalsIgnoreCase(headerListData.get(cellCounter))) {
                                        planId_2 = cellValue;
                                    } else if ("PlanId P003".equalsIgnoreCase(headerListData.get(cellCounter))) {
                                        planId_3 = cellValue;
                                    }
                                    dataMap.put(headerListData.get(cellCounter), cellValue);
                                }
                            } else {
                                if ("PolicyData".equalsIgnoreCase(sheet.getSheetName()) && "PlanId".equalsIgnoreCase(headerListData.get(cellCounter))) {
                                    planId = cellValue;
                                }
                                dataMap.put(headerListData.get(cellCounter), cellValue);
                            }
                        }
                        break;
                    case NUMERIC:    //field that represents number cell type
                        if (headerListData.get(cellCounter).toUpperCase().contains("DATE")) {
                            dataMap.put(headerListData.get(cellCounter), formatCells("" + cell.getNumericCellValue()));
                        } else {
                            Object obj = formatter.formatCellValue(cell);
                            if ("PolicyData".equalsIgnoreCase(sheet.getSheetName())) {
                                if ("PolicyId".equalsIgnoreCase(headerListData.get(cellCounter))) {
                                    policyId = Integer.parseInt(obj.toString());
                                } else if ("Policy holder Id".equalsIgnoreCase(headerListData.get(cellCounter))) {
                                    policyHolderId = Integer.parseInt(obj.toString());
                                } else if ("Individual accumulated deductible for this year (2016)".equalsIgnoreCase(headerListData.get(cellCounter))) {
                                    individualDeductible = obj.toString();
                                } else if ("Family accumulated deductible for this year (2016)".equalsIgnoreCase(headerListData.get(cellCounter))) {
                                    familyDeductible = obj.toString();
                                }
                            }
                            dataMap.put(headerListData.get(cellCounter), obj);
                        }
                        break;
                    default:
                }
                cellCounter++;
            }
            if (!planId.isEmpty()) {
                setPolicyHolderDetailsMapData(policyId, individualDeductible, familyDeductible, policyHolderId, planId);
            }
            if (!mainCategory.isEmpty()) {
                setPolicyPlanRule(mainCategory, subCategory, planId_1, planId_2, planId_3);
            }
            if (rowCounter != 0) {
                if (!dataMap.isEmpty()) {
                    if ("PlanDescriptions".equalsIgnoreCase(sheet.getSheetName())) {
                        if (dataMap.containsKey("PlanId")) {
                            planIdList.add(dataMap.get("PlanId").toString());
                            planDeductibleMap.put(dataMap.get("PlanId").toString(),
                                    dataMap.get("ANNUAL DECUCTIBLE  (INDIVIDUAL)").toString()+ SEPARATOR +dataMap.get("ANNUAL DEDUCTIBLE (FAMILY)").toString());
                        }
                        planDescriptionsDataList.add(dataMap);
                    } else if ("PolicyData".equalsIgnoreCase(sheet.getSheetName())) {
                        if (dataMap.containsKey("PolicyId")) {
                            policyIdList.add(dataMap.get("PolicyId").toString());
                        }
                        if (dataMap.containsKey("Policy holder Id")) {
                            policyHolderIdList.add(dataMap.get("Policy holder Id").toString());
                        }
                        policyDataList.add(dataMap);
                    } else if ("PlanCoverage".equalsIgnoreCase(sheet.getSheetName())) {
                        planCoverageList.add(dataMap);
                    } else if ("SampleTransactions".equalsIgnoreCase(sheet.getSheetName())) {
                        sampleTransactionsList.add(dataMap);
                    }
                }
            }
            rowCounter++;
        }
    }

    private void setPolicyHolderDetailsMapData(int policyId, String individualDeductible, String familyDeductible, int policyHolderId, String planId) {
        policyHolderPlanMapData.put(policyId + SEPARATOR + policyHolderId, planId + SEPARATOR + individualDeductible + SEPARATOR + familyDeductible);
    }

    private void setPolicyPlanRule(String mainCategory, String subCategory, String planId_1, String planId_2, String planId_3) {
        if ("Inpatient Hospital Care".equalsIgnoreCase(mainCategory) || "Maternity".equalsIgnoreCase(mainCategory)) {
            policyPlanRuleMapData.put(mainCategory + SEPARATOR + mainCategory + SEPARATOR + "P001", planId_1);
            policyPlanRuleMapData.put(mainCategory + SEPARATOR + mainCategory + SEPARATOR + "P002", planId_2);
            policyPlanRuleMapData.put(mainCategory + SEPARATOR + mainCategory + SEPARATOR + "P003", planId_3);
        } else {
            policyPlanRuleMapData.put(mainCategory + SEPARATOR + subCategory + SEPARATOR + "P001", planId_1);
            policyPlanRuleMapData.put(mainCategory + SEPARATOR + subCategory + SEPARATOR + "P002", planId_2);
            policyPlanRuleMapData.put(mainCategory + SEPARATOR + subCategory + SEPARATOR + "P003", planId_3);
        }

    }

    static private String formatCells(String cellValue) {
        if (!cellValue.isEmpty()) {
            cellValue = cellValue.replace(".0", "");
        }
        return cellValue;
    }

    public  List<PolicyData>  processUploadedData() {
        String planId;
        String policyId;
        String policyholderId;
        String individualDeductible;
        String familyDeductible;
        String mainCategory;
        String subCategory;
        String errorCode;
        String errorCodeDescription;
        String planRuleUsed;
        String dateOfService ;
        String billedAmont ;
        Map<String, Object> dataMap = sampleTransactionsList.get(0);
        List<PolicyData> policyDataBeanList = new ArrayList<>() ;
        PolicyData policyData ;
        setFieldHeaderList(dataMap);
        setBeanFieldHeaderList(dataMap);
        setHeaderList();
        for (Map<String, Object> stringObjectMap : sampleTransactionsList) {
            dataMap = stringObjectMap;
            Iterator<String> mapIterator = dataMap.keySet().iterator();
            planId = "";
            policyId = "";
            policyholderId = "";
            individualDeductible = "";
            familyDeductible = "";
            mainCategory = "";
            subCategory = "";
            planRuleUsed = "";
            dateOfService = "";
            billedAmont = "";
            errorCode = "";
            errorCodeDescription = "";
            policyData = new PolicyData();
            while (mapIterator.hasNext()) {
                String key = mapIterator.next();
                Object value = dataMap.get(key);
                if ("PolicyId".equals(key)) {
                    policyId = value.toString();
                    if (!policyIdList.contains(value.toString())) {
                        errorCode = ErrorCode.POLICY_ID_NON_EXISTENCE.getCode();
                        errorCodeDescription = ErrorCode.POLICY_ID_NON_EXISTENCE.getDescription();
                    }
                } else if ("Policy holder Id".equals(key)) {
                    policyholderId = value.toString();
                    if (!policyHolderIdList.contains(value.toString())) {
                        errorCode = ErrorCode.POLICY_HOLDER_NON_EXISTENCE.getCode();
                        errorCodeDescription = ErrorCode.POLICY_HOLDER_NON_EXISTENCE.getDescription();
                    }
                } else if ("Coverage Main Category".equals(key)) {
                    mainCategory = value.toString();
                } else if ("Coverage Sub Category".equals(key)) {
                    subCategory = value.toString();
                }else if ("Date of service".equals(key)) {
                    dateOfService = value.toString();
                }else if ("Billed Amont".equals(key)) {
                    billedAmont = value.toString();
                }
            }
            if (errorCode.isEmpty()) {
                String mapKey = policyId + SEPARATOR + policyholderId;
                if (policyHolderPlanMapData.containsKey(mapKey)) {
                    String planData = policyHolderPlanMapData.get(mapKey).toString();
                    String[] dataArray = planData.split(SEPARATOR);
                    if (dataArray.length == 3) {
                        planId = dataArray[0];
                        individualDeductible = dataArray[1];
                        familyDeductible = dataArray[2];
                    }
                    if (!planId.isEmpty() && !mainCategory.isEmpty() && !subCategory.isEmpty()) {
                        //System.out.println("planId::::"+planId);
                        String categoryKey = mainCategory + SEPARATOR + subCategory + SEPARATOR + planId;
                        if ("Inpatient Hospital Care".equalsIgnoreCase(mainCategory) || "Maternity".equalsIgnoreCase(mainCategory)) {
                            categoryKey = mainCategory + SEPARATOR + mainCategory + SEPARATOR + planId;
                        }
                        if (policyPlanRuleMapData.containsKey(categoryKey)) {
                            planRuleUsed = policyPlanRuleMapData.get(categoryKey);
                            //System.out.println("planRuleUsed::"+planRuleUsed);
                        }
                    }
                }
            }
            policyData.setPolicyHolderId(policyholderId);
            policyData.setDateofService(dateOfService);
            policyData.setBilledAmont(billedAmont);
            policyData.setCoverageMainCategory(mainCategory);
            policyData.setCoverageSubCategory(subCategory);
            policyData.setPolicyId(policyId);
            policyData.setPolicyHolderPays("");
            policyData.setPlanPays("");
            policyData.setRuleUsed(planRuleUsed);
            policyData.setFamilyAccumulatedDeductibleServiceDate(familyDeductible);
            policyData.setIndividualAccumulatedDeductibleServiceDate(individualDeductible);
            policyData.setProcessingMessage("");
            policyData.setErrorCode(errorCode);
            policyData.setErrorMessage(errorCodeDescription);
            policyDataBeanList.add(policyData);
        }
        return policyDataBeanList ;
    }

    public  static PolicyData  getProcessUploadedData(PolicyData policyInputData) {
        String planId = "";
        String policyId;
        String policyholderId;
        String individualDeductible = null;
        String familyDeductible = null;
        String errorCode;
        String errorCodeDescription;
        String planRuleUsed;
        planRuleUsed = "";
        errorCode = "";
        errorCodeDescription = "";
        Double billedAmount;
        Double inputPlanIndividualDeductibleAmount = 0.00 ;
        Double inputPlanFamilyDeductibleAmount = 0.00 ;
        Double policyHolderPays = 0.00 ;
        Double planPays = 0.00;
        Double totalPlanIndividualAmount = 0.00 ;
        Double totalPlanFamilyAmount = 0.00 ;
        int rulePercentage = 1 ;
        String processingRule = PLAN_DO_NOT_PAYS;
        boolean planMetFlag = false ;
        policyId = policyInputData.getPolicyId();
        if (!policyIdList.contains(policyId)) {
            errorCode = ErrorCode.POLICY_ID_NON_EXISTENCE.getCode();
            errorCodeDescription = ErrorCode.POLICY_ID_NON_EXISTENCE.getDescription();
        }
        policyholderId = policyInputData.getPolicyHolderId();
        if (!policyHolderIdList.contains(policyholderId)) {
            errorCode = ErrorCode.POLICY_HOLDER_NON_EXISTENCE.getCode();
            errorCodeDescription = ErrorCode.POLICY_HOLDER_NON_EXISTENCE.getDescription();
        }
        if (errorCode.isEmpty()) {
            String mapKey = policyId + SEPARATOR + policyholderId;
            if (policyHolderPlanMapData.containsKey(mapKey)) {
                String planData = policyHolderPlanMapData.get(mapKey).toString();
                String[] dataArray = planData.split(SEPARATOR);
                if (dataArray.length == 3) {
                    planId = dataArray[0];
                    individualDeductible = dataArray[1];
                    familyDeductible = dataArray[2];
                }
                if (!planId.isEmpty() && !policyInputData.getCoverageMainCategory().isEmpty() && !policyInputData.getCoverageSubCategory().isEmpty()) {
                    //System.out.println("planId::::"+planId);
                    String categoryKey = policyInputData.getCoverageMainCategory() + SEPARATOR + policyInputData.getCoverageSubCategory() + SEPARATOR + planId;
                    if ("Inpatient Hospital Care".equalsIgnoreCase(policyInputData.getCoverageMainCategory()) || "Maternity".equalsIgnoreCase(policyInputData.getCoverageMainCategory())) {
                        categoryKey = policyInputData.getCoverageMainCategory() + SEPARATOR + policyInputData.getCoverageMainCategory() + SEPARATOR + planId;
                    }
                    if (policyPlanRuleMapData.containsKey(categoryKey)) {
                        planRuleUsed = policyPlanRuleMapData.get(categoryKey);
                        //System.out.println("planRuleUsed::"+planRuleUsed);
                    }
                }
            }
            String key = policyId+ SEPARATOR +policyholderId ;
            if(individualPolicyHolderPlanCalulationMapData.containsKey(key)){
                inputPlanIndividualDeductibleAmount = Double.parseDouble(individualPolicyHolderPlanCalulationMapData.get(key).toString());
            }
            if(familyPolicyHolderPlanCalulationMapData.containsKey(policyId)){
                inputPlanFamilyDeductibleAmount = Double.parseDouble(familyPolicyHolderPlanCalulationMapData.get(policyId).toString());
            }
            billedAmount = getFormattedDoubleValue(policyInputData.getBilledAmont()) ;

            policyHolderPays = 0.00 ;
            planPays = 0.00;

            if(planDeductibleMap.containsKey(planId)){
                String[] planAmount = planDeductibleMap.get(planId).toString().split(SEPARATOR);
                totalPlanIndividualAmount = getFormattedDoubleValue(planAmount[0]);
                totalPlanFamilyAmount = getFormattedDoubleValue(planAmount[1]);
            }
            int usedPlanRulePercentage = planRuleUsed.contains("%")?Integer.parseInt(planRuleUsed.substring(0, planRuleUsed.indexOf('%'))):0;
            int usedPlanRuleDollar = planRuleUsed.contains("$")?Integer.parseInt(planRuleUsed.substring(planRuleUsed.indexOf('$') + 1)):0;
            if(billedAmount+inputPlanIndividualDeductibleAmount <= totalPlanIndividualAmount){
                policyHolderPays = billedAmount ;
                planPays = 0.00;
                processingRule = PLAN_DO_NOT_PAYS;
            }
            else{
                if(!planRuleUsed.isEmpty()) {
                    if(planRuleUsed.contains("%")){
                        rulePercentage = usedPlanRulePercentage;
                        policyHolderPays = calculatePercentage(billedAmount,100-rulePercentage)  ;
                        planPays = calculatePercentage(billedAmount,rulePercentage) ;
                    }
                    else if(planRuleUsed.contains("$")){
                        rulePercentage = usedPlanRuleDollar;
                        policyHolderPays = billedAmount - rulePercentage;
                        planPays = Double.valueOf(rulePercentage);
                    }
                    processingRule = PLAN_PAYS_INDIVIDUAL.replace("0%",String.valueOf(rulePercentage)+"%");
                    planMetFlag  = true ;
                }
            }
            if(!planMetFlag){
                if(billedAmount+inputPlanFamilyDeductibleAmount <= totalPlanFamilyAmount){
                    policyHolderPays = billedAmount ;
                    planPays = 0.00;
                    processingRule = PLAN_DO_NOT_PAYS;
                }
                else{
                    if(!planRuleUsed.isEmpty()) {
                        if(planRuleUsed.contains("%")){
                            rulePercentage = usedPlanRulePercentage;
                            policyHolderPays = calculatePercentage(billedAmount,100-rulePercentage)  ;
                            planPays = calculatePercentage(billedAmount,rulePercentage) ;
                        }
                        else if(planRuleUsed.contains("$")){
                            rulePercentage = usedPlanRuleDollar;
                            policyHolderPays = billedAmount - rulePercentage;
                            planPays = Double.valueOf(rulePercentage);
                        }
                        processingRule = PLAN_PAYS_FAMILY.replace("0%",String.valueOf(rulePercentage)+"%");
                    }
                }
            }
            inputPlanIndividualDeductibleAmount += policyHolderPays;
            inputPlanFamilyDeductibleAmount += policyHolderPays ;
            individualPolicyHolderPlanCalulationMapData.put(key,inputPlanIndividualDeductibleAmount);
            familyPolicyHolderPlanCalulationMapData.put(policyId,inputPlanFamilyDeductibleAmount);
            policyInputData.setPolicyHolderPays("$  "+String.format("%.2f",policyHolderPays));
            policyInputData.setPlanPays(planPays.equals(0.0)?0:"$  "+String.format("%.2f",planPays));
            policyInputData.setRuleUsed(planRuleUsed);
            policyInputData.setIndividualAccumulatedDeductibleServiceDate(inputPlanIndividualDeductibleAmount.equals(0.0)?0:"$  "+String.format("%.2f",inputPlanIndividualDeductibleAmount));
            policyInputData.setFamilyAccumulatedDeductibleServiceDate(inputPlanFamilyDeductibleAmount.equals(0.0)?0:"$  "+String.format("%.2f",inputPlanFamilyDeductibleAmount));
            policyInputData.setProcessingMessage(processingRule);
        }
        else{
            policyInputData.setErrorCode(errorCode);
            policyInputData.setErrorMessage(errorCodeDescription);
        }

        return policyInputData ;
    }
    private static Double calculatePercentage(Double amount,int rulePercentage){
        Double percentage = (amount *rulePercentage)/100 ;
        return percentage ;
    }
    private static Double getFormattedDoubleValue(Object obj){
        String data = obj.toString() ;
        if(!data.isEmpty()){
            data = data.replace("$","");
            data = data.replace(",","");
        }
        else{
            data = "0.00" ;
        }
        return  Double.parseDouble(data);
    }

    private static void setHeaderList() {
        headerList.add("policyId");
        headerList.add("policyHolderId");
        headerList.add("dateofService");
        headerList.add("coverageMainCategory");
        headerList.add("coverageSubCategory");
        headerList.add("billedAmont");
        headerList.add("policyHolderPays");
        headerList.add("planPays");
        headerList.add("ruleUsed");
        headerList.add("individualAccumulatedDeductibleServiceDate");
        headerList.add("familyAccumulatedDeductibleServiceDate");
        headerList.add("errorCode");
        headerList.add("errorMessage");
        headerList.add("processingMessage");
    }

    private void setFieldHeaderList(Map<String, Object> dataMap) {
        fieldHeaderList.addAll(dataMap.keySet());
        fieldHeaderList.add("Policy Holder pays");
        fieldHeaderList.add("Plan Pays");
        fieldHeaderList.add("Rule used");
        fieldHeaderList.add("Individual accumulated deductible as of service date");
        fieldHeaderList.add("Family accumulated deductible as of service date");
        fieldHeaderList.add("Error Code");
        fieldHeaderList.add("Error Message");
        fieldHeaderList.add("Processing message");
    }

    private void setBeanFieldHeaderList(Map<String, Object> dataMap) {
        beanFieldHeaderList.addAll(dataMap.keySet());
    }
    public static List<String> getBeanFieldHeaderList(){
        return beanFieldHeaderList ;
    }
    public static List<String> getHearerList(){
        return headerList ;
    }

    public static List<String> getFieldHearerList(){
        return fieldHeaderList ;

    }
}